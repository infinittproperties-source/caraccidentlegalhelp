# 🏛️ Illinois Car Accident Case Analyzer

A standalone, single-file HTML tool for Illinois car accident victims to evaluate their case, estimate damages, and identify top Chicago-area personal injury attorneys.

**No server required. No dependencies. Runs entirely in the browser.**

---

## 🚀 Quick Start

```bash
# Clone the repo
git clone https://github.com/YOUR_USERNAME/il-accident-analyzer.git

# Open in your browser
open index.html
```

Or host it instantly with GitHub Pages:
1. Push to a GitHub repo
2. Go to **Settings → Pages → Deploy from branch → main → / (root)**
3. Your app is live at `https://YOUR_USERNAME.github.io/il-accident-analyzer`

---

## 📋 Features

### 7 Tabs, One Complete Case File

| Tab | What It Does |
|---|---|
| **Accident Details** | Full intake questionnaire — collision type, county, fault, injuries, financial damages. Auto-calculates case value with low/mid/high settlement estimates. |
| **Vehicle & Total Loss** | Enter year/make/model/mileage. Generates a Cars.com search link to find your car's actual market value (ACV). Rental car calculator. Total loss rights summary. |
| **Damages & Fault** | Interactive comparative negligence calculator (Illinois 51% bar rule). Pain & suffering multiplier (1.5×–5×). Net recovery after fault reduction. Negotiation strategy benchmarks. |
| **Evidence Checklist** | 19-item checklist with urgency flags. Click to track what you've collected. Progress bar. Identifies critical time-sensitive items (dashcam, surveillance footage). |
| **Deadlines** | Color-coded Illinois legal deadlines from "today" to 2 years. Covers all critical actions including statute of limitations (735 ILCS 5/13-202). |
| **IL Law** | Quick reference for key statutes, minimum insurance requirements, and 2022–2026 settlement benchmarks from the Illinois verdict database. |
| **Top IL Firms** | 6 top Chicago personal injury firms with $100M+ recovered. Includes firm name, lead attorneys, total recovered, notable cases, address, and phone. |
| **Full Report** | Generates a printable PDF-ready case summary with all your inputs, damage calculations, action items, and firm contacts in one document. |

---

## ⚖️ Legal Framework Built In

- **735 ILCS 5/2-1116** — Modified comparative negligence (51% bar rule)
- **735 ILCS 5/13-202** — 2-year statute of limitations
- **625 ILCS 5/11-408** — Duty to report accidents
- **625 ILCS 5/12-610.2** — Texting while driving prohibition
- **625 ILCS 5/3-707** — Driving without insurance
- **755 ILCS 5/27-6** — Illinois Survival Act (wrongful death)

---

## 🏢 Law Firms Included

| Firm | Total Recovered | Phone |
|---|---|---|
| Power Rogers, LLP | $6 Billion+ | (312) 236-9381 |
| Clifford Law Offices | $5 Billion+ | (312) 899-9090 |
| Salvi, Schostok & Pritchard P.C. | $3 Billion+ | (312) 372-1227 |
| Disparti Law Group | $2 Billion+ | (312) 600-6000 |
| McNabola & Associates | $300 Million+ | (312) 888-8000 |
| Phillips Law Offices | $500 Million+ | (312) 346-4262 |

All firms work on **contingency** — you pay nothing unless they win. All offer free consultations.

---

## 📊 Settlement Data Sources

- Illinois Lawsuit Information Center verdict database
- Rosenfeld Injury Lawyers Illinois settlement data
- Jury Verdict Research (median IL personal injury verdict: $26,624)
- Cook County 2022–2026 case outcomes

---

## 🛠️ Tech Stack

- Pure HTML5 / CSS3 / Vanilla JavaScript
- Zero dependencies, zero build steps
- Google Fonts (Playfair Display, DM Sans, DM Mono) via CDN
- Cars.com search integration (deep link URL)
- Print-to-PDF via `window.print()`

---

## 📁 File Structure

```
il-accident-analyzer/
├── index.html      # The entire application (single file)
└── README.md       # This file
```

---

## ⚠️ Legal Disclaimer

This tool is for **informational and strategic planning purposes only**. It does not constitute legal advice and does not create an attorney-client relationship. Settlement estimates are based on publicly available Illinois verdict data and general benchmarks — actual results depend on the specific facts, evidence, and representation in your case.

**Always consult a licensed Illinois personal injury attorney before taking legal action.**

---

## 📝 License

MIT — free to use, modify, and distribute.

---

*Built for Illinois car accident victims. Data current as of April 2026.*
